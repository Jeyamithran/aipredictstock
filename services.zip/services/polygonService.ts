
export interface OptionContract {
    ticker: string;
    underlying_ticker: string;
    strike_price: number;
    expiration_date: string;
    contract_type: 'call' | 'put';
    details?: {
        volume: number;
        open_interest: number;
        implied_volatility: number;
        bid?: number;
        ask?: number;
        last_price?: number;
        greeks?: {
            delta: number;
            gamma: number;
            theta: number;
            vega: number;
        };
    };
}

export interface OptionsFlowData {
    sentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    putCallRatio: number;
    netGamma: number;
    topCalls: OptionContract[];
    topPuts: OptionContract[];
    totalCallVol: number;
    totalPutVol: number;
}

const BASE_URL = 'https://api.polygon.io/v3';

export const getPolygonApiKey = () => {
    // Priority: Vite Env -> Window Env -> LocalStorage
    if ((import.meta as any).env?.VITE_POLYGON_API_KEY) return (import.meta as any).env.VITE_POLYGON_API_KEY;
    if ((typeof window !== 'undefined') && (window as any).env?.VITE_POLYGON_API_KEY) return (window as any).env.VITE_POLYGON_API_KEY;
    if (typeof window !== 'undefined') return localStorage.getItem('polygon_api_key') || '';
    return '';
};

export const fetchOptionsChain = async (ticker: string): Promise<OptionContract[]> => {
    const apiKey = getPolygonApiKey();
    if (!apiKey) throw new Error("Polygon API Key missing");

    // Get nearest expiration (simplified for MVP: just next Friday or similar)
    // For MVP, we'll just query the Snapshot endpoint for the underlying to get ALL active options
    // Warning: This can be huge. Better to filter by near-term expiration.

    // Strategy: Get contracts expiring in the next 7-14 days
    const today = new Date();
    const nextWeek = new Date(today);
    nextWeek.setDate(today.getDate() + 14);

    const dateStr = nextWeek.toISOString().split('T')[0]; // YYYY-MM-DD

    // Endpoint: /v3/snapshot/options/{underlyingAsset}
    // This returns the entire chain snapshot with Greeks!
    const url = `${BASE_URL}/snapshot/options/${ticker}?apiKey=${apiKey}&limit=250`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            if (response.status === 429) throw new Error("Polygon Rate Limit Exceeded");
            throw new Error(`Polygon API Error: ${response.statusText}`);
        }

        const data = await response.json();
        if (!data.results) return [];

        // Map to our interface
        return data.results.map((r: any) => ({
            ticker: r.ticker,
            underlying_ticker: r.underlying_asset.ticker,
            strike_price: r.details.strike_price,
            expiration_date: r.details.expiration_date,
            contract_type: r.details.contract_type,
            details: {
                volume: r.day.volume || 0,
                open_interest: r.open_interest || 0,
                implied_volatility: r.implied_volatility || 0,
                bid: r.last_quote?.bid || 0,
                ask: r.last_quote?.ask || 0,
                last_price: r.day.close || r.last_quote?.ask || 0,
                greeks: r.greeks ? {
                    delta: r.greeks.delta || 0,
                    gamma: r.greeks.gamma || 0,
                    theta: r.greeks.theta || 0,
                    vega: r.greeks.vega || 0
                } : undefined
            }
        }));

    } catch (error) {
        console.error("Polygon Fetch Error:", error);
        throw error;
    }
};

export const calculateOptionsFlow = (contracts: OptionContract[]): OptionsFlowData => {
    let totalCallVol = 0;
    let totalPutVol = 0;
    let netGamma = 0;

    const calls: OptionContract[] = [];
    const puts: OptionContract[] = [];

    contracts.forEach(c => {
        const vol = c.details?.volume || 0;
        const gamma = c.details?.greeks?.gamma || 0;
        const delta = c.details?.greeks?.delta || 0;

        if (c.contract_type === 'call') {
            totalCallVol += vol;
            netGamma += (gamma * vol); // Gamma Exposure proxy
            calls.push(c);
        } else {
            totalPutVol += vol;
            netGamma -= (gamma * vol); // Puts have negative gamma impact usually (dealer short gamma)
            puts.push(c);
        }
    });

    // Sort by Volume
    calls.sort((a, b) => (b.details?.volume || 0) - (a.details?.volume || 0));
    puts.sort((a, b) => (b.details?.volume || 0) - (a.details?.volume || 0));

    const pcr = totalCallVol > 0 ? totalPutVol / totalCallVol : 1;

    // Sentiment Logic
    let sentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
    if (pcr < 0.7) sentiment = 'BULLISH';
    else if (pcr > 1.0) sentiment = 'BEARISH';

    // Refine with Gamma
    if (netGamma > 0 && sentiment === 'BULLISH') sentiment = 'BULLISH'; // Confirmed
    if (netGamma < 0 && sentiment === 'BEARISH') sentiment = 'BEARISH'; // Confirmed

    return {
        sentiment,
        putCallRatio: pcr,
        netGamma,
        topCalls: calls.slice(0, 5),
        topPuts: puts.slice(0, 5),
        totalCallVol,
        totalPutVol
    };
};

// New Interface for Trade Analysis
export interface TradeIntent {
    aggressionScore: number; // -1 (Net Sell) to 1 (Net Buy)
    isHedge: boolean;
    flowType: 'BLOCK' | 'SWEEP' | 'RETAIL';
    dominantSide: 'BID' | 'ASK' | 'MID';
    whaleConfidence: 'HIGH' | 'LOW';
}

// 1. NEW: Fetch Individual Trades to spot Sweeps/Blocks
export const fetchContractTrades = async (contractTicker: string): Promise<any[]> => {
    const apiKey = getPolygonApiKey();
    const today = new Date().toISOString().split('T')[0];

    // Get last 50 trades for this specific contract
    const url = `https://api.polygon.io/v3/trades/${contractTicker}?timestamp=${today}&limit=50&sort=timestamp&order=desc&apiKey=${apiKey}`;

    try {
        const response = await fetch(url);
        const data = await response.json();
        return data.results || [];
    } catch (e) {
        console.error("Failed to fetch trades", e);
        return [];
    }
};

// 2. NEW: The "Hedge vs Bet" Algorithm
export const analyzeInstitutionalIntent = (
    trades: any[],
    currentStockTrend: 'BULLISH' | 'BEARISH',
    contractType: 'call' | 'put'
): TradeIntent => {
    let blockCount = 0;
    let sweepCount = 0;

    trades.forEach(t => {
        const size = t.size || 0;

        // Heuristic 1: Detect Block vs Sweep
        // Block: Large single print (e.g. > 200 contracts)
        // Sweep: Burst of identical timestamps (simplified here to just Size check for MVP)
        if (size > 200) {
            blockCount++;
        } else {
            sweepCount++;
        }
    });

    // 3. The "Fake Hedge" Filter Logic
    let isHedge = false;

    // Logic: If Block Trade count is high AND it opposes the trend, assume Hedge.
    if (blockCount > sweepCount) {
        if (currentStockTrend === 'BULLISH' && contractType === 'put') isHedge = true; // Protecting Longs
        if (currentStockTrend === 'BEARISH' && contractType === 'call') isHedge = true; // Protecting Shorts
    }

    // Logic: If Sweeps are high AND matches trend (or reversal logic), it's a Bet.
    const aggressionScore = sweepCount > blockCount ? 0.8 : 0.2; // Placeholder for true Bid/Ask math

    return {
        aggressionScore: isHedge ? 0 : aggressionScore,
        isHedge,
        flowType: blockCount > sweepCount ? 'BLOCK' : 'SWEEP',
        dominantSide: 'ASK', // This needs real NBBO comparison
        whaleConfidence: isHedge ? 'LOW' : 'HIGH'
    };
};

export const filterPromisingContracts = async (
    contracts: OptionContract[],
    sentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL'
): Promise<OptionContract[]> => {
    if (sentiment === 'NEUTRAL') return [];

    const isBullish = sentiment === 'BULLISH';
    const targetType = isBullish ? 'call' : 'put';

    // Phase 1: Hard Filters (Math)
    const baseCandidates = contracts.filter(c => {
        if (c.contract_type !== targetType) return false;

        const vol = c.details?.volume || 0;
        const bid = c.details?.bid || 0;
        const ask = c.details?.ask || 0;
        const spread = ask - bid;

        // Liquidity: Institutional Size
        if (vol < 1000) return false;

        // Spread: Tight Execution
        if (spread > 0.05 && spread > (ask * 0.02)) return false; // Max 2% spread or 5 cents

        const delta = Math.abs(c.details?.greeks?.delta || 0);

        // Delta Sweet Spot (ATM Gamma Zone)
        return delta >= 0.40 && delta <= 0.65;
    });

    // Phase 2: The "Whale Intent" Check (Async)
    // We only analyze the top 3 candidates to save API calls (Rate Limit Protection)
    const top3 = baseCandidates.sort((a, b) => (b.details?.volume || 0) - (a.details?.volume || 0)).slice(0, 3);

    const validatedCandidates = await Promise.all(top3.map(async (c) => {
        // Fetch recent trades for this specific contract
        // Note: 'ticker' in OptionContract is the full option symbol (e.g. O:SPY...)
        const trades = await fetchContractTrades(c.ticker);

        // Analyze Intent
        const intent = analyzeInstitutionalIntent(trades, sentiment, c.contract_type);

        // FILTER: Remove Hedges
        if (intent.isHedge) return null;

        // FILTER: Remove "Passive" Blocks (Low Aggression)
        if (intent.flowType === 'BLOCK' && intent.aggressionScore < 0.5) return null;

        return { ...c, intent }; // Attach intent data for the UI/AI
    }));

    // Remove nulls (filtered hedges) and sort by Aggression
    return validatedCandidates
        .filter((c): c is OptionContract & { intent: TradeIntent } => c !== null)
        .sort((a, b) => b.intent.aggressionScore - a.intent.aggressionScore);
};
