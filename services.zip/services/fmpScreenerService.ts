import { ScannerProfile } from '../types';

const runtimeEnv = (typeof window !== 'undefined') ? (window as any).env : {};
const FMP_API_KEY = runtimeEnv?.VITE_FMP_API_KEY || (import.meta as any).env?.VITE_FMP_API_KEY;
const FMP_BASE_URL = 'https://financialmodelingprep.com/api/v3';

interface ScreenerParams {
    marketCapMoreThan?: number;
    volumeMoreThan?: number;
    priceMoreThan?: number;
    sector?: string;
    industry?: string;
    betaMoreThan?: number;
    isEtf?: boolean;
    isActivelyTrading?: boolean;
    limit?: number;
}

const getParamsForProfile = (profile: ScannerProfile): ScreenerParams => {
    const baseParams = {
        limit: 50,
        isEtf: false,
        isActivelyTrading: true,
        priceMoreThan: 2,
        volumeMoreThan: 100000
    };

    switch (profile) {
        case 'hedge_fund':
            return {
                ...baseParams,
                marketCapMoreThan: 1000000000, // $1B
                volumeMoreThan: 500000,
                priceMoreThan: 5
            };
        case 'pro_trader':
            return {
                ...baseParams,
                volumeMoreThan: 1000000, // High liquidity
                betaMoreThan: 1.2
            };
        case 'catalyst':
            return {
                ...baseParams,
                volumeMoreThan: 200000
            };
        case 'bio_analyst':
            return {
                ...baseParams,
                sector: 'Healthcare',
                industry: 'Biotechnology',
                marketCapMoreThan: 200000000, // $200M
                limit: 100 // Need more candidates to filter for trials
            };
        case 'immediate_breakout':
            return {
                ...baseParams,
                volumeMoreThan: 300000,
                betaMoreThan: 1.0
            };
        case 'high_growth':
            return {
                ...baseParams,
                sector: 'Technology',
                marketCapMoreThan: 50000000, // Micro caps ok
                limit: 60
            };
        default:
            return baseParams;
    }
};

const FALLBACK_TICKERS = ['SPY', 'QQQ', 'NVDA', 'AMD', 'MSFT', 'AAPL', 'TSLA', 'AMZN', 'GOOGL', 'META'];

export const fetchScreenerResults = async (profile: ScannerProfile): Promise<string[]> => {
    if (!FMP_API_KEY) {
        console.warn("FMP API Key missing, using fallback tickers.");
        return FALLBACK_TICKERS;
    }

    const params = getParamsForProfile(profile);
    const queryParams = new URLSearchParams({
        apikey: FMP_API_KEY,
        limit: params.limit?.toString() || '50'
    });

    if (params.marketCapMoreThan) queryParams.append('marketCapMoreThan', params.marketCapMoreThan.toString());
    if (params.volumeMoreThan) queryParams.append('volumeMoreThan', params.volumeMoreThan.toString());
    if (params.priceMoreThan) queryParams.append('priceMoreThan', params.priceMoreThan.toString());
    if (params.sector) queryParams.append('sector', params.sector);
    if (params.industry) queryParams.append('industry', params.industry);
    if (params.betaMoreThan) queryParams.append('betaMoreThan', params.betaMoreThan.toString());
    if (params.isEtf !== undefined) queryParams.append('isEtf', params.isEtf.toString());
    if (params.isActivelyTrading !== undefined) queryParams.append('isActivelyTrading', params.isActivelyTrading.toString());

    try {
        const response = await fetch(`${FMP_BASE_URL}/stock-screener?${queryParams.toString()}`);

        if (response.status === 403 || response.status === 402) {
            console.warn(`FMP Screener access restricted (${response.status}). Your plan may not support this endpoint. Using fallback tickers.`);
            return FALLBACK_TICKERS;
        }

        if (!response.ok) {
            throw new Error(`FMP Screener API error: ${response.status}`);
        }
        const data = await response.json();

        // Return list of tickers
        const tickers = data.map((item: any) => item.symbol);

        if (tickers.length === 0) {
            console.warn("FMP Screener returned 0 results. Using fallback tickers.");
            return FALLBACK_TICKERS;
        }

        return tickers;
    } catch (error) {
        console.error("Error fetching FMP screener results:", error);
        return FALLBACK_TICKERS; // Fail gracefully, ensure AI has something to analyze
    }
};

export const fetchDynamicScreener = async (params: ScreenerParams): Promise<string[]> => {
    if (!FMP_API_KEY) return [];

    const queryParams = new URLSearchParams({
        apikey: FMP_API_KEY,
        limit: params.limit?.toString() || '10'
    });

    if (params.marketCapMoreThan) queryParams.append('marketCapMoreThan', params.marketCapMoreThan.toString());
    if (params.volumeMoreThan) queryParams.append('volumeMoreThan', params.volumeMoreThan.toString());
    if (params.priceMoreThan) queryParams.append('priceMoreThan', params.priceMoreThan.toString());
    if (params.sector) queryParams.append('sector', params.sector);
    if (params.industry) queryParams.append('industry', params.industry);
    if (params.betaMoreThan) queryParams.append('betaMoreThan', params.betaMoreThan.toString());
    if (params.isEtf !== undefined) queryParams.append('isEtf', params.isEtf.toString());
    if (params.isActivelyTrading !== undefined) queryParams.append('isActivelyTrading', params.isActivelyTrading.toString());

    try {
        const response = await fetch(`https://financialmodelingprep.com/stable/company-screener?${queryParams.toString()}`);
        if (!response.ok) return [];
        const data = await response.json();
        return data.map((item: any) => item.symbol);
    } catch (error) {
        console.error("Error fetching dynamic screener:", error);
        return [];
    }
};
